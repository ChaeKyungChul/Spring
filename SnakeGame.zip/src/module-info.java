module Game {
	requires java.desktop;
	requires java.sql;
}